<link rel="stylesheet" type="text/css" href="/static/index/css/webbase.css" />
    <link rel="stylesheet" type="text/css" href="/static/index/css/pages-seckillOrder.css" />
<div class="yui3-u-1-6 list">

                    <div class="person-info">
                        <div class="person-photo"><img src="/static/index/img/_/photo.png" alt=""></div>
                        <div class="person-account">
                            <span class="name">Michelle</span>
                            <span class="safe">账户安全</span>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="list-items">
                        <dl>
							<dt><i>·</i> 订单中心</dt>
							<dd ><a href="{{url('/index/user_index')}}" >我的订单</a></dd>
							<dd><a href="home-order-pay.html" ></a></dd>
							<dd><a href="home-order-send.html"  ></a></dd>
							<dd><a href="home-order-receive.html" ></a></dd>
							<dd><a href="home-order-evaluate.html" ></a></dd>
						</dl>
						<dl>
							<dt><i>·</i> </dt>
							<dd><a href="home-person-collect.html"></a></dd>
							<dd><a href="home-person-footmark.html"></a></dd>
						</dl>
						<dl>
							<dt><i>·</i> </dt>
						</dl>
						<dl>
							<dt><i></i> 设置</dt>
							<dd><a href="{{url('/user/user_info')}}">个人信息</a></dd>
							<dd><a href="{{url('user/user_address')}}"  >地址管理</a></dd>
							
						</dl>
                    </div>
                </div>