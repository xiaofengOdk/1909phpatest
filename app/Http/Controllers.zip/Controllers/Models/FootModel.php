<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FootModel extends Model
{
    protected $table='foot';
    protected $primaryKey='id';
    public $timestamps=false;
}
